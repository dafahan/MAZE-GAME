#include <iostream>
#include <windows.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <cstdlib>
#include <curses.h>
using namespace std;


int main()
{		
	initscr();
	mvprintw(1,1, "=========================================");
	mvprintw(2,1, "=---------| Teka (Tebak Angka) |--------=");
	mvprintw(3,1,"=========================================");
	mvprintw(6,1, "Pemenangnya adalah\n\n");
	sleep(5);
	mvprintw(6,20,".");
	refresh();
	Sleep (1000);
	mvprintw(6,21,".");
	refresh();
	Sleep(1000);
	mvprintw(6,22,".");
	refresh();
	Sleep (1000);
	getch();
	endwin();
}
