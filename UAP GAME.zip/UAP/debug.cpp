#include<fstream>
#include<conio.h>
#include<curses.h>
#include<Windows.h>
#include<bits/stdc++.h>
using namespace std;
bool acc;


int main()
{	
	char s[100];
	initscr();
	getstr(s);
	endwin();
	string a="dafa";
	if(a==s)cout<<1;
}
