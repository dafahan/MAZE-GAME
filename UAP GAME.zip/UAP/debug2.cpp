#include<fstream>
#include<conio.h>
#include<curses.h>
#include<Windows.h>
#include<bits/stdc++.h>
using namespace std;
bool acc;
int main()
{	vector<string>UserList;
	string line;
	ifstream files("ListUser.txt");
	char tmp;
	string temp;
	while(!files.eof()){
		files.get(tmp);
		if(tmp==' '||tmp=='\n'){
			UserList.push_back(temp);
			temp="";
		}else{
		temp+=tmp;
	}
	}
	temp.erase(temp.end()-1);
	UserList.push_back(temp);
	for(auto i:UserList)cout<<i<<endl;
	for(auto i:UserList){
		if(i=="admin")cout<<"FOUND";
	}
}
